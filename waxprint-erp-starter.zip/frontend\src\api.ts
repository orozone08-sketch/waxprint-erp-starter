export const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
export async function getJson<T>(path:string):Promise<T>{const r=await fetch(`${API}${path}`);if(!r.ok)throw new Error(await r.text());return r.json()}
export async function postJson<T>(path:string, body:any):Promise<T>{const r=await fetch(`${API}${path}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r.ok)throw new Error(await r.text());return r.json()}
export async function postForm<T>(path:string, body:FormData):Promise<T>{const r=await fetch(`${API}${path}`,{method:'POST',body});if(!r.ok)throw new Error(await r.text());return r.json()}
