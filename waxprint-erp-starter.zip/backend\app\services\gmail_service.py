import email
import imaplib
import re
from datetime import datetime
from email.header import decode_header, make_header
from email.utils import parseaddr, parsedate_to_datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app import models
from app.config import settings


def status():
    imap_configured = bool(settings.gmail_user and settings.gmail_app_password)
    oauth_configured = bool(settings.gmail_client_id and settings.gmail_client_secret and settings.gmail_refresh_token)
    mode = "imap" if imap_configured else "oauth" if oauth_configured else "none"
    return {
        "enabled": settings.gmail_enabled,
        "configured": imap_configured or oauth_configured,
        "mode": mode,
        "user": settings.gmail_user if settings.gmail_user != "me" else "",
        "mailbox": settings.gmail_mailbox,
        "fetch_query": settings.gmail_fetch_query,
        "fetch_limit": settings.gmail_fetch_limit,
        "pubsub_topic": settings.gmail_pubsub_topic or None,
        "archive_label": settings.gmail_archive_label,
    }


def reconcile(db: Session):
    current = status()
    if not settings.gmail_enabled:
        return {"ok": False, "message": "Gmail integration is disabled. Set GMAIL_ENABLED=true in backend/.env."}
    if not current["configured"]:
        return {"ok": False, "message": "Gmail credentials are incomplete. Add GMAIL_USER and GMAIL_APP_PASSWORD in backend/.env."}
    if current["mode"] != "imap":
        return {"ok": False, "message": "OAuth credentials are configured, but this starter currently fetches via Gmail IMAP app password."}
    return _fetch_with_imap(db)


def _fetch_with_imap(db: Session):
    imported = 0
    skipped_existing = 0
    errors: list[str] = []
    fetched = 0
    mail = imaplib.IMAP4_SSL(settings.gmail_imap_host, settings.gmail_imap_port)
    try:
        mail.login(settings.gmail_user, settings.gmail_app_password.replace(" ", ""))
        typ, _ = mail.select(settings.gmail_mailbox)
        if typ != "OK":
            return {"ok": False, "message": f"Could not open mailbox {settings.gmail_mailbox}."}

        typ, data = mail.uid("search", None, settings.gmail_fetch_query or "UNSEEN")
        if typ != "OK":
            return {"ok": False, "message": "Gmail search failed."}

        uids = (data[0] or b"").split()
        selected = uids[-max(settings.gmail_fetch_limit, 1):]
        fetched = len(selected)

        for uid in reversed(selected):
            external_id = f"gmail:{uid.decode('ascii', errors='ignore')}"
            exists = db.scalar(select(models.InboxMessage.id).where(models.InboxMessage.external_message_id == external_id))
            if exists:
                skipped_existing += 1
                continue
            try:
                typ, message_data = mail.uid("fetch", uid, "(BODY.PEEK[])")
                if typ != "OK":
                    errors.append(f"Could not fetch UID {uid.decode(errors='ignore')}")
                    continue
                raw = next((part[1] for part in message_data if isinstance(part, tuple)), None)
                if not raw:
                    errors.append(f"Empty message UID {uid.decode(errors='ignore')}")
                    continue
                msg = email.message_from_bytes(raw)
                sender = _decode_header(msg.get("From", ""))
                sender_email = parseaddr(sender)[1].lower()
                subject = _decode_header(msg.get("Subject", ""))
                received_at = _received_at(msg.get("Date"))
                customer = _match_customer(db, sender_email)
                inbox = models.InboxMessage(
                    source="gmail",
                    external_message_id=external_id,
                    sender=sender,
                    subject=subject or "(no subject)",
                    body=_message_body(msg),
                    received_at=received_at,
                    archived=False,
                    status="MATCHED" if customer else "RECEIVED",
                    customer_id=customer.id if customer else None,
                )
                db.add(inbox)
                imported += 1
            except Exception as exc:
                errors.append(f"UID {uid.decode(errors='ignore')}: {exc}")
        db.commit()
    finally:
        try:
            mail.logout()
        except Exception:
            pass

    return {
        "ok": not errors,
        "message": f"Fetched {fetched} Gmail message(s), imported {imported}, skipped {skipped_existing}.",
        "fetched": fetched,
        "imported": imported,
        "skipped_existing": skipped_existing,
        "errors": errors,
    }


def _decode_header(value: str) -> str:
    if not value:
        return ""
    return str(make_header(decode_header(value)))


def _received_at(value: str | None) -> datetime:
    if not value:
        return datetime.utcnow()
    try:
        parsed = parsedate_to_datetime(value)
        return parsed.replace(tzinfo=None)
    except Exception:
        return datetime.utcnow()


def _match_customer(db: Session, sender_email: str):
    if not sender_email:
        return None
    return db.scalar(select(models.Customer).where(models.Customer.email == sender_email))


def _message_body(msg) -> str:
    plain_parts: list[str] = []
    html_parts: list[str] = []
    parts = msg.walk() if msg.is_multipart() else [msg]
    for part in parts:
        disposition = part.get_content_disposition()
        if disposition == "attachment":
            continue
        content_type = part.get_content_type()
        if content_type not in {"text/plain", "text/html"}:
            continue
        payload = part.get_payload(decode=True)
        if not payload:
            continue
        charset = part.get_content_charset() or "utf-8"
        text = payload.decode(charset, errors="replace").strip()
        if content_type == "text/plain":
            plain_parts.append(text)
        else:
            html_parts.append(_strip_html(text))
    body = "\n\n".join(plain_parts or html_parts)
    return re.sub(r"\n{3,}", "\n\n", body).strip()[:10000]


def _strip_html(value: str) -> str:
    value = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", value)
    value = re.sub(r"(?s)<br\s*/?>", "\n", value)
    value = re.sub(r"(?s)</p\s*>", "\n", value)
    value = re.sub(r"(?s)<.*?>", " ", value)
    return re.sub(r"[ \t]+", " ", value).strip()
