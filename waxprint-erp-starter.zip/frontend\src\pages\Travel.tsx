import {type ReactNode, useEffect, useMemo, useState} from 'react'
import {BadgeCheck, BriefcaseBusiness, IndianRupee, Plane, RefreshCw, WalletCards} from 'lucide-react'
import {getJson, postJson} from '../api'
import {Job} from '../types'
import {jumpTo} from '../ui'

type Employee={id:number;code:string;name:string;department:string;role:string;monthly_salary:number}
type TravelRow={id:number;employee_id:number;employee_name:string;job_id:number|null;job_number:string|null;trip_date:string;destination:string;purpose:string;advance_amount:number;flight_amount:number;hotel_amount:number;taxi_amount:number;porter_amount:number;other_amount:number;settled_amount:number;total_expense:number;balance:number;status:string;notes:string|null}
type TravelForm={employee_id:string;job_id:string;trip_date:string;destination:string;purpose:string;advance_amount:string;flight_amount:string;hotel_amount:string;taxi_amount:string;porter_amount:string;other_amount:string;settled_amount:string;notes:string}

const money=(n:number)=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n||0)
const today=()=>new Date().toISOString().slice(0,10)

export default function Travel(){
 const[employees,setEmployees]=useState<Employee[]>([])
 const[jobs,setJobs]=useState<Job[]>([])
 const[travel,setTravel]=useState<TravelRow[]>([])
 const[form,setForm]=useState<TravelForm>({employee_id:'',job_id:'',trip_date:today(),destination:'',purpose:'Customer visit',advance_amount:'0',flight_amount:'0',hotel_amount:'0',taxi_amount:'0',porter_amount:'0',other_amount:'0',settled_amount:'0',notes:''})
 const[notice,setNotice]=useState('')
 const[error,setError]=useState('')
 const[loading,setLoading]=useState(false)

 const load=async()=>{
  setError('')
  const [employeeRows,jobRows,travelRows]=await Promise.all([getJson<Employee[]>('/api/employees'),getJson<Job[]>('/api/jobs'),getJson<TravelRow[]>('/api/travel')])
  setEmployees(employeeRows);setJobs(jobRows);setTravel(travelRows)
  if(employeeRows.length&&!form.employee_id)setForm(f=>({...f,employee_id:String(employeeRows[0].id)}))
 }
 useEffect(()=>{load().catch(x=>setError(String(x)))},[])

 const openTrips=travel.filter(t=>t.status!=='SETTLED')
 const totalAdvance=travel.reduce((sum,t)=>sum+t.advance_amount,0)
 const totalExpense=travel.reduce((sum,t)=>sum+t.total_expense,0)
 const totalBalance=travel.reduce((sum,t)=>sum+t.balance,0)
 const draftExpense=Number(form.flight_amount||0)+Number(form.hotel_amount||0)+Number(form.taxi_amount||0)+Number(form.porter_amount||0)+Number(form.other_amount||0)
 const draftBalance=Number(form.advance_amount||0)+Number(form.settled_amount||0)-draftExpense
 const employeeById=useMemo(()=>Object.fromEntries(employees.map(e=>[e.id,e])),[employees])

 const saveTravel=async()=>{
  if(!form.employee_id||!form.destination||!form.purpose){setError('Select employee and enter destination and purpose.');return}
  setLoading(true);setError('');setNotice('')
  try{
   const result=await postJson<{status:string;balance:number}>('/api/travel',{employee_id:Number(form.employee_id),job_id:form.job_id?Number(form.job_id):null,trip_date:form.trip_date,destination:form.destination,purpose:form.purpose,advance_amount:Number(form.advance_amount)||0,flight_amount:Number(form.flight_amount)||0,hotel_amount:Number(form.hotel_amount)||0,taxi_amount:Number(form.taxi_amount)||0,porter_amount:Number(form.porter_amount)||0,other_amount:Number(form.other_amount)||0,settled_amount:Number(form.settled_amount)||0,notes:form.notes||null})
   setNotice(`Travel entry saved. ${result.status==='SETTLED'?'Settled':'Balance '+money(result.balance)}.`)
   setForm({...form,destination:'',purpose:'Customer visit',advance_amount:'0',flight_amount:'0',hotel_amount:'0',taxi_amount:'0',porter_amount:'0',other_amount:'0',settled_amount:'0',notes:''})
   await load()
  }catch(x){setError(String(x))}
  finally{setLoading(false)}
 }

 return <section className="panel">
  <div className="travelHeader">
   <div><h2>Travel / Advances</h2><p>Trip advances, flight, hotel, taxi, porter expenses and settlement balance.</p></div>
   <button className="secondaryBtn" onClick={()=>load().catch(x=>setError(String(x)))} disabled={loading}><RefreshCw size={16}/>Refresh</button>
  </div>

  <div className="platformStats">
   <Stat icon={<Plane size={18}/>} label="Open Trips" value={openTrips.length} onClick={()=>jumpTo('open-settlements')}/>
   <Stat icon={<IndianRupee size={18}/>} label="Advances" value={money(totalAdvance)} onClick={()=>jumpTo('travel-ledger')}/>
   <Stat icon={<WalletCards size={18}/>} label="Expenses" value={money(totalExpense)} onClick={()=>jumpTo('travel-ledger')}/>
   <Stat icon={<BadgeCheck size={18}/>} label="Balance" value={money(totalBalance)} onClick={()=>jumpTo('open-settlements')}/>
  </div>

  {notice&&<div className="successBox">{notice}</div>}
  {error&&<div className="errorBox">{error}</div>}

  <section className="travelGrid subPanel" id="travel-entry">
   <div>
    <div className="panelHead"><h2>Trip Entry</h2><small>Advance + settlement</small></div>
    <div className="travelForm">
     <label>Employee<select value={form.employee_id} onChange={e=>setForm({...form,employee_id:e.target.value})}>{employees.map(e=><option key={e.id} value={e.id}>{e.name} / {e.role}</option>)}</select></label>
     <label>Job link<select value={form.job_id} onChange={e=>setForm({...form,job_id:e.target.value})}><option value="">General company trip</option>{jobs.map(j=><option key={j.id} value={j.id}>{j.number} / {j.customer}</option>)}</select></label>
     <label>Date<input type="date" value={form.trip_date} onChange={e=>setForm({...form,trip_date:e.target.value})}/></label>
     <label>Destination<input value={form.destination} onChange={e=>setForm({...form,destination:e.target.value})} placeholder="Mumbai / Surat / Jaipur"/></label>
     <label className="wideField">Purpose<input value={form.purpose} onChange={e=>setForm({...form,purpose:e.target.value})}/></label>
     <label>Advance<input inputMode="decimal" value={form.advance_amount} onChange={e=>setForm({...form,advance_amount:e.target.value})}/></label>
     <label>Flight<input inputMode="decimal" value={form.flight_amount} onChange={e=>setForm({...form,flight_amount:e.target.value})}/></label>
     <label>Hotel<input inputMode="decimal" value={form.hotel_amount} onChange={e=>setForm({...form,hotel_amount:e.target.value})}/></label>
     <label>Taxi<input inputMode="decimal" value={form.taxi_amount} onChange={e=>setForm({...form,taxi_amount:e.target.value})}/></label>
     <label>Porter<input inputMode="decimal" value={form.porter_amount} onChange={e=>setForm({...form,porter_amount:e.target.value})}/></label>
     <label>Other<input inputMode="decimal" value={form.other_amount} onChange={e=>setForm({...form,other_amount:e.target.value})}/></label>
     <label>Settled / returned<input inputMode="decimal" value={form.settled_amount} onChange={e=>setForm({...form,settled_amount:e.target.value})}/></label>
     <label className="wideField">Notes<input value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Bill no, approval, trip note"/></label>
     <div className="travelPreview"><span>Total expense <b>{money(draftExpense)}</b></span><span>Balance <b>{money(draftBalance)}</b></span><span>{draftBalance>=0?'Return due':'Claim due'} <b>{money(Math.abs(draftBalance))}</b></span></div>
     <button className="primaryBtn" onClick={saveTravel} disabled={loading||!employees.length}><Plane size={16}/>Save Travel Entry</button>
    </div>
   </div>

   <div id="open-settlements">
    <div className="panelHead"><h2>Open Settlements</h2><small>{openTrips.length} open</small></div>
    <div className="travelCards">
     {openTrips.slice(0,6).map(t=><article className="travelCard" key={t.id}><Plane size={18}/><span><b>{t.destination}</b><small>{t.employee_name} / {t.trip_date}</small></span><strong className={t.balance<0?'badAmount':''}>{money(t.balance)}</strong></article>)}
     {!openTrips.length&&<div className="emptyState"><BadgeCheck size={28}/><p>No open travel settlements.</p></div>}
    </div>
   </div>
  </section>

  <section className="subPanel" id="travel-ledger">
   <div className="panelHead"><h2>Travel Ledger</h2><small>{travel.length} trip(s)</small></div>
   <table><thead><tr><th>Date</th><th>Employee</th><th>Destination</th><th>Job</th><th>Advance</th><th>Expense</th><th>Balance</th><th>Status</th></tr></thead><tbody>{travel.map(t=><tr key={t.id}><td>{t.trip_date}</td><td><b>{t.employee_name}</b><small className="mutedCell">{employeeById[t.employee_id]?.role||''}</small></td><td>{t.destination}<small className="mutedCell">{t.purpose}</small></td><td>{t.job_number||'General'}</td><td>{money(t.advance_amount)}</td><td>{money(t.total_expense)}</td><td>{money(t.balance)}</td><td><span className={t.status==='SETTLED'?'badge success':'badge warn'}>{pretty(t.status)}</span></td></tr>)}</tbody></table>
  </section>
 </section>
}

function Stat({icon,label,value,onClick}:{icon:ReactNode;label:string;value:string|number;onClick:()=>void}){return <button className="setupCard clickableStat" type="button" onClick={onClick}>{icon}<span><b>{value}</b><small>{label}</small></span></button>}
function pretty(value:string){return value.toLowerCase().replace(/_/g,' ').replace(/\b\w/g,s=>s.toUpperCase())}
